//
//  OnboardingManager.swift
//  Returns
//
//  Created by Jonathan Stickney on 5/16/25.
//


// OnboardingManager.swift
import Foundation
import SwiftUI

class OnboardingManager: ObservableObject {
    @Published var showOnboarding: Bool
    
    init() {
        // Check if user has completed onboarding before
        //self.showOnboarding = !UserDefaults.standard.bool(forKey: "hasCompletedOnboarding")
        self.showOnboarding = true
    }
    
    func completeOnboarding() {
        showOnboarding = false
        UserDefaults.standard.set(true, forKey: "hasCompletedOnboarding")
    }
    
    func resetOnboarding() {
        showOnboarding = true
        UserDefaults.standard.set(false, forKey: "hasCompletedOnboarding")
    }
}
