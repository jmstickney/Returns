//
//  OnboardingView.swift
//  Returns
//
//  Created by Jonathan Stickney on 5/16/25.
//


// OnboardingView.swift
import SwiftUI

struct OnboardingView: View {
    @ObservedObject var onboardingManager: OnboardingManager
    @State private var currentPage = 0
    
    private let pageCount = 4
    
    var body: some View {
        ZStack {
            // Background
            Color("LaunchBackgroundColor")
                .ignoresSafeArea()
            
            VStack {
                // Header with logo
                if currentPage == 0 {
                    Spacer()
                    
                    Image(systemName: "arrow.triangle.2.circlepath.circle")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 80, height: 80)
                        .foregroundColor(.white)
                    
                    Text("Welcome to\nRefund Radar")
                        .font(.title)
                        .fontWeight(.bold)
                        .multilineTextAlignment(.center)
                        .foregroundColor(.white)
                        .padding(.top, 20)
                    
                    Text("Never lose track of returns again")
                        .font(.subheadline)
                        .foregroundColor(.white.opacity(0.8))
                        .padding(.top, 10)
                    
                    Spacer()
                } else {
                    // Page content
                    TabView(selection: $currentPage) {
                        // Skip first page (title screen)
                        // Page 1 - Track Returns
                        OnboardingPageView(
                            title: "Track Your Returns",
                            subtitle: "Keep all your returns organized in one place",
                            description: "Add products you're returning, set reminders, and track refund status so you never lose money on returns again.",
                            imageName: "cube.box.fill",
                            backgroundColor: Color.blue
                        )
                        .tag(1)
                        
                        // Page 2 - Gmail Integration
                        OnboardingPageView(
                            title: "Scan Gmail for Returns",
                            subtitle: "Automatically find returns in your email",
                            description: "Connect your Gmail account to automatically detect purchases and returns from your inbox.",
                            imageName: "envelope.fill",
                            backgroundColor: Color.red
                        )
                        .tag(2)
                        
                        // Page 3 - Tracking & Notifications
                        OnboardingPageView(
                            title: "Get Reminders & Updates",
                            subtitle: "Never miss a return deadline",
                            description: "Receive notifications for return deadlines and track shipping status to ensure your returns are processed correctly.",
                            imageName: "bell.fill",
                            backgroundColor: Color.orange
                        )
                        .tag(3)
                        
                        // Page 4 - Start
                        VStack(spacing: 30) {
                            Image(systemName: "checkmark.circle.fill")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 100, height: 100)
                                .foregroundColor(.green)
                            
                            Text("You're all set!")
                                .font(.title)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                            
                            Text("Start tracking your returns and get your money back")
                                .font(.headline)
                                .multilineTextAlignment(.center)
                                .foregroundColor(.white)
                                .padding(.horizontal)
                            
                            Button(action: {
                                onboardingManager.completeOnboarding()
                            }) {
                                Text("Get Started")
                                    .font(.headline)
                                    .foregroundColor(.white)
                                    .frame(height: 55)
                                    .frame(maxWidth: .infinity)
                                    .background(Color.green)
                                    .cornerRadius(10)
                                    .padding(.horizontal, 30)
                            }
                        }
                        .padding()
                        .tag(4)
                    }
                    .tabViewStyle(PageTabViewStyle())
                    .indexViewStyle(PageIndexViewStyle(backgroundDisplayMode: .always))
                }
                
                // Navigation buttons
                if currentPage == 0 {
                    Button(action: {
                        withAnimation {
                            currentPage = 1
                        }
                    }) {
                        Text("Get Started")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(height: 55)
                            .frame(maxWidth: .infinity)
                            .background(Color.blue)
                            .cornerRadius(10)
                            .padding(.horizontal, 30)
                    }
                    .padding(.bottom, 50)
                    
                    Button(action: {
                        onboardingManager.completeOnboarding()
                    }) {
                        Text("Skip")
                            .font(.subheadline)
                            .foregroundColor(.white.opacity(0.8))
                    }
                    .padding(.bottom, 20)
                } else if currentPage < 4 {
                    HStack {
                        Button(action: {
                            onboardingManager.completeOnboarding()
                        }) {
                            Text("Skip")
                                .font(.subheadline)
                                .foregroundColor(.white.opacity(0.8))
                        }
                        
                        Spacer()
                        
                        Button(action: {
                            withAnimation {
                                currentPage += 1
                            }
                        }) {
                            Text("Next")
                                .font(.headline)
                                .foregroundColor(.white)
                                .padding(.horizontal, 30)
                                .padding(.vertical, 10)
                                .background(Color.blue)
                                .cornerRadius(10)
                        }
                    }
                    .padding(.horizontal, 30)
                    .padding(.bottom, 30)
                }
            }
        }
    }
}